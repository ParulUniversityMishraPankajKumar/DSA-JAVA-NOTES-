class Node{
    //parameters
    int data ; 
    Node next ;
    
    Node(int data){
        this.data = data ;
        this.next = null ;
    }
    
}
public class Main
{   
    // print my LL
    public static void printLL(Node head){
        Node curr = head ;
        while(curr != null){
            System.out.print(curr.data +" --> ");
            curr = curr.next ;
        }
         System.out.print(" null ");
    }
    
    
    //insert element at the END 
    static public Node InsetAtEnd(Node head,int data){
        Node NewNode = new Node(data);
        Node curr = head ;
        if(head == null) return NewNode ;
        while(curr.next != null){
            curr = curr.next ;
        }
        
        curr.next = NewNode ;
        return head ;
        
    } 
    
    //inset element at the front 
    static public  Node InsetAtFront(Node head,int data){
        Node NewNode = new Node(data);
        NewNode.next = head ;
        return NewNode ;
    }
    
    
    //DELETE NODE FORM THE END
    public static Node DeleteFromEnd(Node head){
        if(head == null) return null;
        if(head.next == null) return null ;
        Node curr = head ;
        while(curr.next.next != null) curr = curr.next ;
        curr.next = null ;
        return head ;
    }
    
    
    //deleting node from front
    public static Node DeleteFromFront(Node head){
        return head.next ;
    }
    
    
    //length of the linklist 
    public static int findLength(Node head){
        
      Node curr = head ;
      int cnt = 0 ;
      while(curr != null){
          curr = curr.next ;
          cnt++;
      }
      
      return cnt ;
    }
    
    //find the middle of the LINKLIST
    public static int findMiddle(Node head){
        
        Node slow = head ;
        Node fast = head ;
        
        while(fast != null && fast.next != null){
            fast = fast.next.next;
            slow = slow.next ;
        }
        
        //return ans 
        return slow.data ;
    }
    
	public static void main(String[] args) {
	   
	   //implementataion of LL 
	   //************** ADDING A NODE TO THE LINKLIST ****************//
	   Node head = new Node(2) ;
	   
	   
	   //************** ADDING A NODE AT END  ****************//
	   head = InsetAtEnd(head,3);
	   head = InsetAtEnd(head,4);
	   head = InsetAtEnd(head,5);
	   head = InsetAtEnd(head,6);
	   
	   
	   printLL(head);    // Printing the linklist with refeence to head 
	   System.out.println();
	   head = InsetAtFront(head,1);
	   printLL(head);
	   System.out.println();
	   head = InsetAtFront(head,0);
	   System.out.println("ORIGINAL LINKLIST : ");
	   printLL(head);
	   System.out.println();
	   
	   
	   //************** DELETE THE NODE FROM THE END  *********************//
	   System.out.println("Afer deleting the last node : ");
	   //head = DeleteFromEnd(head);
	   //printLL(head);
	   
	   //************** DELETE THE NODE FROM THE END  *********************//
	   System.out.println("Afer deleting NODE FROM THE FRONT : ");
	   head = DeleteFromFront(head);
	   printLL(head);
	   System.out.println();
	   //head = DeleteFromFront(head);
	   //printLL(head);
	   
	   
	   //********************* size of linklist ******************************//
	   
	   int size = findLength(head);
	   System.out.println ("size of the linklist is : "+ size);
	   
	   
	   //*********************** Middle of Linklist *************************//
	   
	  
	   int  mid = findMiddle(head);
	   System.out.print("mid of the linklist is:"+ mid ) ;
	   
	}
}
